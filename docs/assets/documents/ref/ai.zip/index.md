# Home - DK MEDCOM REFERRAL LM v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://medcomehmi.dk/ig/dk-medcom-ref-lm/ImplementationGuide/dk-medcom-ref-lm | *Version*:0.1.0 |
| Draft as of 2026-06-16 | *Computable Name*:DKMEDCOMREFERRALLM |

# FHIR Henvisninger

**Bemærk: Dette er en disclaimer for hele denne IG**

 Alt er mock-up på user stories og diagrammer og er på ingen måde nødvendigvis fuldt dækkende og fuldt retvisende. Det forsøges til stadighed at blive mere dækkende og mere retvisende. 

 Alt er delvist udarbejdet sammen med AI-værktøjerne Clause og ChatGPT, så justeringer efter deres forslag må påregnes. 

## Krav/User stories

* [Claude User stories](fhir-henvisning-user-stories-v2-claude.md)

## Workflows

* [workflow](workflow.md)
* [workflow2](workflow2.md)
* [workflow3](workflow3.md)
* [Claude workflow](workflow-claude.md)

